# Código Python del paper — guía de uso

Todo el código Python generado durante la reformulación del paper
(nervio de diseño, tests GLS, pipeline de datos reales sobre
`community.xml`, y las figuras principales/suplementarias). No incluye
las iteraciones intermedias de las figuras (versiones v1–v3 del
esquema del nervio, generadores de figuras sueltos anteriores al
estilo unificado) — solo las versiones finales que produjeron los
resultados citados en el paper.

## 01_core/nerve_lib.py

La librería núcleo. Todo lo demás importa de aquí.

- `Context`, `build_nerve`, `build_delta0` — construyen el nervio de
  diseño $\mathcal D(\mathcal U)$ y la matriz de coborde $\delta_0$ a
  partir de una lista de contextos (subcomunidades).
- `gls_test` — el test de coherencia exacto (Proposición 1 /
  Lema del test genérico): $T=\delta_0(y)^\top(\delta_0\Sigma\delta_0^\top)^{-1}\delta_0(y)$.
- `h0_projection` — el estimador de consenso coherente $\widehat c=\Pi_{H^0}^\Sigma(y)$.
- `orth_complement_vector` — genera vectores en $(\ker\delta_0)^\perp$
  para inyectar residuos de incoherencia controlados en las
  validaciones sintéticas.
- `nested_regime_decomposition` — la descomposición exacta por
  régimen vía complemento de Schur (Proposición "Exact nested regime
  decomposition"); reemplaza la suma ingenua por partición de aristas
  que se probó incorrecta.

## 02_realdata_pipeline/ — pipeline sobre `community.xml` (Sección XI)

Correr en este orden:

1. **01_parse_and_organisms.py** — parsea el SBML, identifica los 10
   organismos y sus metabolitos extracelulares intercambiables.
2. **02_build_design.py** — enumera las 45 parejas y las 120 triadas
   candidatas.
3. **03_design_selection.py** — corre el diseño greedy D-armónico
   real sobre las 120 candidatas (estructura solamente, no requiere
   FBA); compara contra el heurístico de mínimo solapamiento y contra
   1000 diseños aleatorios.
4. **04_context_fba.py** — construye y resuelve el LP de FBA conjunta
   por contexto (no por organismo), con pFBA y FVA.
5. **05_run_all_fba.py** — corre FBA/pFBA para los 165 contextos
   (45 parejas + 120 triadas) y cachea los resultados.
6. **06_build_coherence_data.py** — extrae las coordenadas de
   intercambio por par de especies desde las soluciones de pFBA y
   arma el vector de datos $y$ sobre el nervio.
7. **07_fva_sample.py** — caracteriza la degeneración de los óptimos
   de FBA (rango FVA vs. magnitud del flujo puntual) sobre una
   muestra de 6 contextos.

Requiere `community.xml` (el modelo SBML de CarveMe) en el mismo
directorio, y `scipy`, `numpy` instalados (`pip install numpy scipy
--break-system-packages`).

## 03_figures/ — generación de todas las figuras

- **plotstyle.py** — estilo compartido (tipografía Latin Modern,
  paleta reducida, sin títulos incrustados). Todo lo demás lo importa.
- **gen_FIG2-6_main.py** — genera las cinco figuras del cuerpo
  principal: curva de potencia del test base (Fig. 2), recuperación
  del residuo de factorización (Fig. 3), descomposición exacta por
  régimen (Fig. 4), y las dos figuras de datos reales (Fig. 5
  comparación de diseño, Fig. 6 sensibilidad al ruido — estas leen
  `results_summary.json`, generado por el pipeline de la Sección XI).
- **gen_FIGS1-4_supplementary.py** — genera las cuatro figuras del
  material suplementario: QQ-plot de calibración (S1), curvas de
  potencia multi-$d$ (S2), potencia de detección por régimen (S3), y
  greedy vs. aleatorio en un pool sintético (S4).
- **gen_FIG_nerve_schematic.py** — el diagrama conceptual del nervio
  de diseño (Fig. 2 del cuerpo principal, Definición 1).

## Notas

- Todas las cifras citadas en el paper (T=150.92, d=360, log det=115.90
  vs. 106.76 vs. 83.75, etc.) provienen de correr este código tal
  cual, no de estimaciones a mano.
- El error de SBML más costoso de depurar: las especies con
  `boundaryCondition="true"` (todo el pool extracelular +
  `community_biomass`) deben excluirse del balance de masa en el LP,
  o el objetivo de crecimiento evalúa a cero silenciosamente. Ya está
  corregido en `04_context_fba.py`.
