"""Real D-harmonic greedy design over the 120 candidate triads, compared
against the old min-overlap heuristic and random baselines -- structure
only (Fisher information depends only on which coordinates get compared,
not on FBA values), so this is cheap and needs no FBA."""
import json, numpy as np, sys
sys.path.insert(0, '.')
from nerve_lib import Context, build_nerve, build_delta0

data = json.load(open('design_structure.json'))
organism_set = data['organism_set']
pairs = [tuple(p) for p in data['pairs']]
candidate_triads = [tuple(t) for t in data['candidate_triads']]
candidate_overlap = data['candidate_triad_overlap']

def ctx_from_idx(idx_tuple):
    return Context([organism_set[i] for i in idx_tuple])

base_contexts = [ctx_from_idx(p) for p in pairs]

def logdet_info(contexts, sigma2=1.0):
    edges = build_nerve(contexts)
    if not edges:
        return -1e9, 0
    delta0, offs, e_offs = build_delta0(contexts, edges)
    Sigma_diag = np.full(offs[-1], sigma2)
    Gram = delta0 @ np.diag(Sigma_diag) @ delta0.T
    w = np.linalg.eigvalsh(Gram)
    w = w[w > 1e-9 * max(w.max(), 1e-30)] if w.size else w
    return (float(np.sum(np.log(w))) if len(w) else -1e9), len(w)

BUDGET = 24
print("Baseline (45 pairs only):", logdet_info(base_contexts))

# ---- greedy D-harmonic on the full 120-candidate pool ----
import time
t0 = time.time()
current = list(base_contexts)
remaining = list(range(len(candidate_triads)))
chosen_idx = []
trace = [logdet_info(current)[0]]
for step in range(BUDGET):
    best_gain, best_i = -1e18, None
    for i in remaining:
        trial = current + [ctx_from_idx(candidate_triads[i])]
        g, _ = logdet_info(trial)
        if g > best_gain:
            best_gain, best_i = g, i
    current.append(ctx_from_idx(candidate_triads[best_i]))
    remaining.remove(best_i)
    chosen_idx.append(best_i)
    trace.append(best_gain)
print(f"greedy design time: {time.time()-t0:.1f}s")
greedy_logdet = trace[-1]
greedy_triads = [candidate_triads[i] for i in chosen_idx]
print(f"Greedy design (B={BUDGET}) logdet = {greedy_logdet:.3f}")

# ---- old heuristic: 24 triads with SMALLEST 3-way overlap ----
order = sorted(range(len(candidate_triads)), key=lambda i: candidate_overlap[i])
heuristic_idx = order[:BUDGET]
heuristic_triads = [candidate_triads[i] for i in heuristic_idx]
heuristic_logdet, heuristic_d = logdet_info(base_contexts + [ctx_from_idx(t) for t in heuristic_triads])
print(f"Min-overlap heuristic (old paper) logdet = {heuristic_logdet:.3f}")

# ---- random baseline (1000 draws) ----
rng = np.random.default_rng(99)
random_logdets = []
for _ in range(1000):
    idx = rng.choice(len(candidate_triads), size=BUDGET, replace=False)
    ld, _ = logdet_info(base_contexts + [ctx_from_idx(candidate_triads[i]) for i in idx])
    random_logdets.append(ld)
random_logdets = np.array(random_logdets)
print(f"Random designs (n=1000): mean={random_logdets.mean():.3f} "
      f"sd={random_logdets.std():.3f} min={random_logdets.min():.3f} max={random_logdets.max():.3f}")
pct_random_beat_heuristic = float(np.mean(random_logdets >= heuristic_logdet))
pct_random_beat_greedy = float(np.mean(random_logdets >= greedy_logdet))
print(f"fraction of random designs >= heuristic logdet: {pct_random_beat_heuristic:.3f}")
print(f"fraction of random designs >= greedy logdet:    {pct_random_beat_greedy:.3f}")

# exhaustive (all 120 triads) degeneracy check
exhaustive_logdet, exhaustive_d = logdet_info(base_contexts + [ctx_from_idx(t) for t in candidate_triads])
print(f"Exhaustive (all 120 triads): logdet={exhaustive_logdet:.3f} rank(delta0)={exhaustive_d}")
_, greedy_d = logdet_info(base_contexts + [ctx_from_idx(t) for t in greedy_triads])
_, base_d = logdet_info(base_contexts)
print(f"rank(delta0): base-only={base_d}, greedy design={greedy_d}, exhaustive={exhaustive_d}")

with open('design_selection.json', 'w') as f:
    json.dump({
        'greedy_triads': greedy_triads,
        'greedy_logdet': greedy_logdet,
        'greedy_d': greedy_d,
        'heuristic_triads': heuristic_triads,
        'heuristic_logdet': heuristic_logdet,
        'random_logdet_mean': float(random_logdets.mean()),
        'random_logdet_sd': float(random_logdets.std()),
        'pct_random_beat_heuristic': pct_random_beat_heuristic,
        'pct_random_beat_greedy': pct_random_beat_greedy,
        'exhaustive_logdet': exhaustive_logdet,
        'exhaustive_d': exhaustive_d,
        'base_d': base_d,
        'greedy_trace': trace,
    }, f, indent=2)
print("saved design_selection.json")
