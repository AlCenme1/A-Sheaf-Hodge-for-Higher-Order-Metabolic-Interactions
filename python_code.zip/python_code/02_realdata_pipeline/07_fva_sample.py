"""FVA degeneracy characterization on a representative sample of pairwise
contexts, to address Reviewer 2 comment 2 (single-point FBA vs assumed
Gaussian noise)."""
import json, time
import numpy as np
from parse_and_organisms import parse_sbml
from context_fba import build_joint_lp, solve_context_fba, fva_context

species, reactions, params = parse_sbml('/mnt/user-data/uploads/community.xml')
data = json.load(open('design_structure.json'))
organism_set = data['organism_set']
pairs = [tuple(p) for p in data['pairs']]

rng = np.random.default_rng(123)
sample_pairs = [pairs[i] for i in rng.choice(len(pairs), size=6, replace=False)]

widths, mags = [], []
t0 = time.time()
for (i, j) in sample_pairs:
    orgs = [organism_set[i], organism_set[j]]
    res = solve_context_fba(orgs, reactions, species, params, pfba=True)
    if res is None or res['growth_opt'] <= 1e-9:
        continue
    # target: the organism-specific transport reactions (ending in _org)
    # that touch ext species, restricted to a manageable subset (top 15
    # by |pFBA flux|) to keep runtime bounded
    cand = [rid for rid in res['rxn_ids']
            if (rid.endswith(f"_{orgs[0]}") or rid.endswith(f"_{orgs[1]}"))
            and abs(res['flux_pfba'].get(rid, 0)) > 1e-6]
    cand.sort(key=lambda r: -abs(res['flux_pfba'][r]))
    cand = cand[:15]
    fva = fva_context(res, reactions, cand, gamma=1.0)
    for rid, (vmin, vmax) in fva.items():
        if np.isnan(vmin) or np.isnan(vmax):
            continue
        width = vmax - vmin
        mag = abs(res['flux_pfba'][rid])
        widths.append(width); mags.append(mag)
    print(f"  {orgs[0]}-{orgs[1]}: growth={res['growth_opt']:.2f}, "
          f"{len(cand)} reactions FVA'd, elapsed={time.time()-t0:.1f}s")

widths = np.array(widths); mags = np.array(mags)
rel = widths / np.maximum(mags, 1e-6)
print(f"\nFVA degeneracy sample (n={len(widths)} reaction-context pairs, "
      f"{len(sample_pairs)} pairwise contexts, gamma=1.0 i.e. optimal growth fixed):")
print(f"  median FVA range / |pFBA flux|  = {np.median(rel):.3f}")
print(f"  mean   FVA range / |pFBA flux|  = {rel.mean():.3f}")
print(f"  90th pct                        = {np.percentile(rel,90):.3f}")
print(f"  fraction with range > 20% of pFBA magnitude: {np.mean(rel>0.20):.3f}")

with open('fva_sample_results.json','w') as f:
    json.dump({'median_rel_range': float(np.median(rel)), 'mean_rel_range': float(rel.mean()),
               'n_sample': len(widths), 'n_contexts': len(sample_pairs)}, f)
