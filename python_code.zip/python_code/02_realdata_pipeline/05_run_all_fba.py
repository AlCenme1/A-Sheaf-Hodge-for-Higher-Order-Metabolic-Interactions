"""Run joint community FBA + pFBA for all 45 pairs and all 120 candidate
triads (165 contexts total), caching results to disk."""
import json, time, pickle
import numpy as np
from parse_and_organisms import parse_sbml
from context_fba import solve_context_fba

species, reactions, params = parse_sbml('/mnt/user-data/uploads/community.xml')
data = json.load(open('design_structure.json'))
organism_set = data['organism_set']
pairs = [tuple(p) for p in data['pairs']]
triads = [tuple(t) for t in data['candidate_triads']]

all_contexts = [('pair', p) for p in pairs] + [('triad', t) for t in triads]
print(f"Running FBA for {len(all_contexts)} contexts...")

results = {}
t0 = time.time()
n_fail = 0
for k, (kind, idxs) in enumerate(all_contexts):
    orgs = [organism_set[i] for i in idxs]
    res = solve_context_fba(orgs, reactions, species, params, pfba=True)
    key = ",".join(orgs)
    if res is None:
        n_fail += 1
        results[key] = None
    else:
        results[key] = {
            'growth_opt': res['growth_opt'],
            'flux_pfba': res['flux_pfba'],
            'rxn_ids': res['rxn_ids'],
        }
    if (k+1) % 20 == 0:
        print(f"  {k+1}/{len(all_contexts)}  elapsed={time.time()-t0:.1f}s  failures={n_fail}")

print(f"Done in {time.time()-t0:.1f}s, {n_fail} failures out of {len(all_contexts)}")
with open('fba_results.pkl', 'wb') as f:
    pickle.dump(results, f)
print("saved fba_results.pkl")
