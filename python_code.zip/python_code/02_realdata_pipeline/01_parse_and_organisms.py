"""Stage 1-2: SBML parsing and organism/metabolite identification."""
import xml.etree.ElementTree as ET
import re, json, time

NS = {'sbml': 'http://www.sbml.org/sbml/level3/version1/core',
      'fbc': 'http://www.sbml.org/sbml/level3/version1/fbc/version2'}

def parse_sbml(path):
    t0=time.time()
    tree = ET.parse(path)
    root = tree.getroot()
    model = root.find('sbml:model', NS)

    species = {}
    for sp in model.find('sbml:listOfSpecies', NS):
        species[sp.get('id')] = {'compartment': sp.get('compartment'), 'name': sp.get('name',''),
                                  'boundary': sp.get('boundaryCondition', 'false') == 'true'}

    reactions = {}
    for rxn in model.find('sbml:listOfReactions', NS):
        rid = rxn.get('id')
        lb_ref = rxn.get('{%s}lowerFluxBound' % NS['fbc'])
        ub_ref = rxn.get('{%s}upperFluxBound' % NS['fbc'])
        reactants, products = {}, {}
        lor = rxn.find('sbml:listOfReactants', NS)
        if lor is not None:
            for sr in lor:
                reactants[sr.get('species')] = float(sr.get('stoichiometry', 1))
        lop = rxn.find('sbml:listOfProducts', NS)
        if lop is not None:
            for sp_ in lop:
                products[sp_.get('species')] = float(sp_.get('stoichiometry', 1))
        reactions[rid] = {'reactants': reactants, 'products': products,
                           'lb_ref': lb_ref, 'ub_ref': ub_ref}

    params = {}
    lop_params = model.find('sbml:listOfParameters', NS)
    if lop_params is not None:
        for p in lop_params:
            params[p.get('id')] = float(p.get('value', 0))
    print(f"parsed in {time.time()-t0:.1f}s: {len(species)} species, {len(reactions)} reactions, {len(params)} params")
    return species, reactions, params


if __name__ == '__main__':
    species, reactions, params = parse_sbml('/mnt/user-data/uploads/community.xml')

    compartments = {s['compartment'] for s in species.values()}
    organism_set = sorted({re.sub(r'^C_c_', '', c) for c in compartments if c.startswith('C_c_')})
    print(f"Organisms ({len(organism_set)}): {organism_set}")

    ext_species_ids = {sid for sid, s in species.items() if s['compartment'] == 'ext'}
    print(f"Extracellular metabolite pool: {len(ext_species_ids)}")

    def organism_exchange_metabolites(org):
        mets = set()
        suffix = f"_{org}"
        for rid, r in reactions.items():
            if not (rid.endswith(suffix) or rid.startswith('R_EX_')):
                continue
            all_sp = set(r['reactants']) | set(r['products'])
            ext_hit = all_sp & ext_species_ids
            if not ext_hit:
                continue
            org_hit = any(species[s]['compartment'].endswith(suffix) for s in all_sp)
            if org_hit or rid.endswith(suffix):
                mets |= ext_hit
        return mets

    org_mets = {org: organism_exchange_metabolites(org) for org in organism_set}
    for org in organism_set:
        print(f"  {org}: {len(org_mets[org])} exchangeable ext metabolites")

    with open('parsed_cache.json', 'w') as f:
        json.dump({'organism_set': organism_set,
                   'org_mets': {o: sorted(m) for o,m in org_mets.items()}}, f)
    print("cached organism_set/org_mets -> parsed_cache.json")
