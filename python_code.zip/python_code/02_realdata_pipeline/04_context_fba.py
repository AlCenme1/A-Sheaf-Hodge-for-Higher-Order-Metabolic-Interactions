"""Stage 3-4: joint per-context community FBA, pFBA, FVA, and building
the design nerve + coherence data, all on top of nerve_lib.py."""
import numpy as np
from scipy.optimize import linprog
import time

def get_bound(ref, params):
    if ref is None: return None
    return params.get(ref, None)


def build_joint_lp(org_list, reactions, species, params):
    """Build the stoichiometric LP for the union of org_list's reactions
    (id ends with _<org> for org in org_list) plus shared R_EX_ reactions
    touching any of their compartments. Returns (rxn_ids, S, lb, ub,
    met_ids, growth_idx_by_org)."""
    suffixes = [f"_{o}" for o in org_list]
    rxn_ids = []
    for rid in reactions:
        if any(rid.endswith(s) for s in suffixes):
            rxn_ids.append(rid)
    ext_touch_orgs = set()
    for rid in reactions:
        if not rid.startswith('R_EX_'):
            continue
        r = reactions[rid]
        all_sp = set(r['reactants']) | set(r['products'])
        # include this shared exchange rxn if it touches ext AND at least
        # one of our organisms could plausibly use it (checked later via
        # metabolite membership in the stoich matrix build)
        rxn_ids.append(rid)
    rxn_ids = sorted(set(rxn_ids))

    met_ids = sorted({s for rid in rxn_ids
                       for s in (set(reactions[rid]['reactants']) | set(reactions[rid]['products']))
                       if not species[s].get('boundary', False)})
    met_idx = {m: k for k, m in enumerate(met_ids)}
    n_rxn, n_met = len(rxn_ids), len(met_ids)
    import scipy.sparse as sp
    rows, cols, data = [], [], []
    lb = np.zeros(n_rxn); ub = np.zeros(n_rxn)
    for k, rid in enumerate(rxn_ids):
        r = reactions[rid]
        for spid, coeff in r['reactants'].items():
            if spid in met_idx:
                rows.append(met_idx[spid]); cols.append(k); data.append(-coeff)
        for spid, coeff in r['products'].items():
            if spid in met_idx:
                rows.append(met_idx[spid]); cols.append(k); data.append(coeff)
        lo = get_bound(r['lb_ref'], params); hi = get_bound(r['ub_ref'], params)
        lb[k] = lo if lo is not None else -1000.0
        ub[k] = hi if hi is not None else 1000.0
    S = sp.csr_matrix((data, (rows, cols)), shape=(n_met, n_rxn))

    # drop reactions that ended up touching zero of our kept metabolites'
    # rows with nonzero coeff is impossible by construction; but drop
    # R_EX_ reactions that don't touch any organism-relevant ext species
    # (keep all -- ext row balance for those simply stays free/unused)

    growth_idx = {}
    for o in org_list:
        gid = f"Growth_{o}"
        if gid in rxn_ids:
            growth_idx[o] = rxn_ids.index(gid)
    return rxn_ids, S, lb, ub, met_ids, growth_idx


def solve_context_fba(org_list, reactions, species, params, pfba=True):
    rxn_ids, S, lb, ub, met_ids, growth_idx = build_joint_lp(org_list, reactions, species, params)
    n_rxn = len(rxn_ids)
    if not growth_idx or n_rxn == 0:
        return None
    c = np.zeros(n_rxn)
    for gi in growth_idx.values():
        c[gi] = -1.0  # maximize sum of growth reactions (community objective)
    res = linprog(c, A_eq=S, b_eq=np.zeros(len(met_ids)),
                   bounds=list(zip(lb, ub)), method='highs')
    if not res.success:
        return None
    flux = dict(zip(rxn_ids, res.x))
    growth_opt = -res.fun

    flux_pfba = flux
    if pfba and growth_opt > 1e-9:
        import scipy.sparse as sp
        n2 = n_rxn
        growth_row = np.zeros(n2)
        for gi in growth_idx.values():
            growth_row[gi] = 1.0
        # variables: [v (n2), t (n2)]; minimize sum(t) s.t. -t<=v<=t, S v = 0,
        # growth_row . v = growth_opt
        I = sp.eye(n2, format='csr')
        A_ub1 = sp.hstack([I, -I], format='csr')       # v - t <= 0
        A_ub2 = sp.hstack([-I, -I], format='csr')       # -v - t <= 0
        A_ub = sp.vstack([A_ub1, A_ub2], format='csr')
        b_ub = np.zeros(2 * n2)
        S_sp = S
        Z = sp.csr_matrix((S_sp.shape[0], n2))
        A_eq_full = sp.hstack([S_sp, Z], format='csr')
        growth_row_full = sp.csr_matrix(np.concatenate([growth_row, np.zeros(n2)]))
        A_eq_full = sp.vstack([A_eq_full, growth_row_full], format='csr')
        b_eq_full = np.concatenate([np.zeros(len(met_ids)), [growth_opt]])
        c_aux = np.concatenate([np.zeros(n2), np.ones(n2)])
        bounds_full = list(zip(lb, ub)) + [(0, 2000)] * n2
        res2 = linprog(c_aux, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq_full, b_eq=b_eq_full,
                        bounds=bounds_full, method='highs')
        if res2.success:
            flux_pfba = dict(zip(rxn_ids, res2.x[:n2]))

    return {'rxn_ids': rxn_ids, 'flux': flux, 'flux_pfba': flux_pfba,
            'growth_opt': growth_opt, 'S': S, 'met_ids': met_ids, 'lb': lb, 'ub': ub}


def fva_context(fba_result, reactions, target_rxn_ids, gamma=1.0):
    """FVA on a subset of reactions (target_rxn_ids), fixing community
    growth >= gamma * growth_opt. Returns dict rid -> (min, max)."""
    rxn_ids = fba_result['rxn_ids']; S = fba_result['S']
    lb0, ub0 = fba_result['lb'], fba_result['ub']
    n_rxn = len(rxn_ids)
    idx = {r: k for k, r in enumerate(rxn_ids)}
    growth_opt = fba_result['growth_opt']
    growth_row = np.zeros(n_rxn)
    for rid in rxn_ids:
        if rid.startswith('Growth_'):
            growth_row[idx[rid]] = 1.0
    A_ub = -growth_row.reshape(1, -1)
    b_ub = [-gamma * growth_opt]
    out = {}
    for rid in target_rxn_ids:
        if rid not in idx:
            continue
        k = idx[rid]
        c = np.zeros(n_rxn); c[k] = 1.0
        res_min = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=S, b_eq=np.zeros(S.shape[0]),
                           bounds=list(zip(lb0, ub0)), method='highs')
        res_max = linprog(-c, A_ub=A_ub, b_ub=b_ub, A_eq=S, b_eq=np.zeros(S.shape[0]),
                           bounds=list(zip(lb0, ub0)), method='highs')
        vmin = res_min.x[k] if res_min.success else np.nan
        vmax = -res_max.fun if res_max.success else np.nan
        out[rid] = (vmin, vmax)
    return out
