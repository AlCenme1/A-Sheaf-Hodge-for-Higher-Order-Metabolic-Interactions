"""Extract per-context, per-pair net exchange coordinates from the cached
pFBA solutions, build the design nerve, and prepare the delta0 test."""
import json, pickle
import numpy as np
import sys; sys.path.insert(0, '.')
from parse_and_organisms import parse_sbml
from nerve_lib import Context, build_nerve, build_delta0

species, reactions, params = parse_sbml('/mnt/user-data/uploads/community.xml')
data = json.load(open('design_structure.json'))
organism_set = data['organism_set']
org_mets = {o: set(m) for o, m in data.get('org_mets', {}).items()} if 'org_mets' in data else None
cache_om = json.load(open('parsed_cache.json'))
org_mets = {o: set(m) for o, m in cache_om['org_mets'].items()}
fba_results = pickle.load(open('fba_results.pkl', 'rb'))

def organism_ext_flux_for_metabolite(org, met_id, flux_dict):
    suffix = f"_{org}"
    total = 0.0
    for rid, v in flux_dict.items():
        if abs(v) < 1e-9 or not rid.endswith(suffix):
            continue
        r = reactions[rid]
        if met_id in r['products']:
            total += v * r['products'][met_id]
        if met_id in r['reactants']:
            total -= v * r['reactants'][met_id]
    return total

def context_pair_data(orgs, flux_dict):
    """Returns dict (oi,oj)->net exchange rate for every pair in `orgs`
    with a nonempty shared exchangeable-metabolite set."""
    out = {}
    for a in range(len(orgs)):
        for b in range(a+1, len(orgs)):
            oi, oj = orgs[a], orgs[b]
            shared = org_mets[oi] & org_mets[oj]
            if not shared:
                continue
            net = 0.0
            for met in shared:
                fi = organism_ext_flux_for_metabolite(oi, met, flux_dict)
                fj = organism_ext_flux_for_metabolite(oj, met, flux_dict)
                net += fi - fj
            out[(oi, oj)] = net / len(shared)
    return out

# Build nerve_lib Contexts + the raw data vector a_U for a given set of
# (kind, idx-tuple) contexts, matching pairs_of() ordering.
def build_dataset(context_specs):
    contexts = []
    a_blocks = []
    labels = []
    for kind, idxs in context_specs:
        orgs = [organism_set[i] for i in idxs]
        key = ",".join(orgs)
        res = fba_results[key]
        if res is None:
            continue
        pdata = context_pair_data(orgs, res['flux_pfba'])
        ctx = Context(orgs)
        if ctx.dim() == 0:
            continue
        vec = np.zeros(ctx.dim())
        for p, k in ctx.pair_index.items():
            # p is (species_a, species_b) sorted; pdata keyed as (oi,oj) in
            # `orgs` order -- look up either orientation
            if p in pdata:
                vec[k] = pdata[p]
            elif (p[1], p[0]) in pdata:
                vec[k] = -pdata[(p[1], p[0])]
            else:
                vec[k] = 0.0  # shouldn't happen: pairs_of(orgs) subset check
        contexts.append(ctx)
        a_blocks.append(vec)
        labels.append((kind, idxs, orgs))
    y = np.concatenate(a_blocks) if a_blocks else np.array([])
    return contexts, y, labels

if __name__ == '__main__':
    pairs = [tuple(p) for p in data['pairs']]
    triads = [tuple(t) for t in data['candidate_triads']]
    specs = [('pair', p) for p in pairs] + [('triad', t) for t in triads]
    contexts, y, labels = build_dataset(specs)
    print(f"Built {len(contexts)} contexts, |y|={len(y)}")
    print("flux data range:", y.min(), y.max(), "mean/std:", y.mean(), y.std())
    edges = build_nerve(contexts)
    print(f"nerve edges: {len(edges)}")
    with open('coherence_dataset.pkl', 'wb') as f:
        pickle.dump({'contexts': contexts, 'y': y, 'labels': labels}, f)
    print("saved coherence_dataset.pkl")
