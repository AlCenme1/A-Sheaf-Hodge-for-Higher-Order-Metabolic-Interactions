"""Stage: enumerate pairwise contexts + 120 candidate triads (structure
only, no FBA yet), matching the paper's construction."""
import json
from itertools import combinations

cache = json.load(open('parsed_cache.json'))
organism_set = cache['organism_set']
org_mets = {o: set(m) for o, m in cache['org_mets'].items()}
n = len(organism_set)

pairs = []
pair_shared = {}
for i, j in combinations(range(n), 2):
    oi, oj = organism_set[i], organism_set[j]
    shared = org_mets[oi] & org_mets[oj]
    if shared:
        pairs.append((i, j))
        pair_shared[(i, j)] = shared
print(f"Pairwise contexts with >=1 shared exchangeable metabolite: {len(pairs)} / {n*(n-1)//2}")

pair_set = set(pairs)
candidate_triads = []
for i, j, k in combinations(range(n), 3):
    if (i,j) in pair_set and (j,k) in pair_set and (i,k) in pair_set:
        oi, oj, ok_ = organism_set[i], organism_set[j], organism_set[k]
        triple_shared = org_mets[oi] & org_mets[oj] & org_mets[ok_]
        if triple_shared:
            candidate_triads.append(((i,j,k), len(triple_shared)))
print(f"Candidate triads (pairwise-connected AND 3-way shared metabolite): {len(candidate_triads)} / {n*(n-1)*(n-2)//6}")

with open('design_structure.json', 'w') as f:
    json.dump({
        'organism_set': organism_set,
        'pairs': pairs,
        'candidate_triads': [t for t,_ in candidate_triads],
        'candidate_triad_overlap': [c for _,c in candidate_triads],
    }, f)
print("saved design_structure.json")
